import os

PROJECT_NAME = "paradigmatic"
ENV = os.getenv("ENV")

API_PREFIX = "/api/v1"

basedir = os.path.abspath(os.path.dirname(__file__))